let list_country = [];

const country_search_element = document.querySelector(".SearchCountry");
const list_country_element = document.querySelector(".CountryList");
const country_btn_change = document.querySelector(".ChangeCountry");
const list_btn_close = document.querySelector(".Close");
const search_box_input = document.getElementById("country");


function createList() {
    const number_of_countries = list_country.length;

    let i = 1,
        ul_list_id;


    list_country.forEach((country, index) => {
        if (index % Math.ceil(number_of_countries / number_of_ul_lists) == 0) {
            ul_list_id = `list-${i}`;
            list_country.innerHTML += `<ul id='${ul_list_id}'></ul>`;
            i++;
        }

        document.getElementById(`${ul_list_id}`).innerHTML += `
            <li onclick="fetchData('${country.name}')" id="${country.name}">
            ${country.name}
            </li>
        `;
    })
}

let number_of_ul_lists = 3;
createList();

country_btn_change.addEventListener("click", function() {
    search_box_input.value = "";
    resetCountryList();
    country_search_element.classList.toggle("hide");
    country_search_element.classList.add("fadeIn");
});

list_btn_close.addEventListener("click", function() {
    country_search_element.classList.toggle("hide");
});

list_country_element.addEventListener("click", function(e) {
    submitSearchBoxForm(e)

    country_search_element.classList.toggle("hide");
});

search_box_input.addEventListener("country", function() {
    let value = search_box_input.value.toUpperCase();

    list_country.forEach(country => {
        if (country.name.toUpperCase().startsWith(value)) {
            document.getElementById(country.name).classList.remove("hide");
        } else {
            document.getElementById(country.name).classList.add("hide");
        }
    })
})

function resetCountryList() {
    list_country.forEach(country => {
        document.getElementById(country.name).classList.remove("hide");
    })
}