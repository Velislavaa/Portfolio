let user_country_selected;
let vaccinesChart;

function fetchData(user_country) {
    user_country_selected = user_country;
}

function submitSearchBoxForm(e) {
    e.preventDefault()

    var country = user_country_selected;
    let getVaccinationHistoryFor30days = "https://disease.sh/v3/covid-19/vaccine/coverage/countries/" + country + "/?lastdays=30"
    let getVaccinationHistoryFor15days = "https://disease.sh/v3/covid-19/vaccine/coverage/countries/" + country + "/?lastdays=15"
    let getVaccinationHistoryAll = "https://disease.sh/v3/covid-19/vaccine/coverage/countries/" + country + "/?lastdays=all"

    async function getHistory15(getVaccinationHistoryFor15days) {
        let response = await fetch(getVaccinationHistoryFor15days)
        let info = await response.json()
        return info;
    }
    getHistory15(getVaccinationHistoryFor15days).then(function(info) {
        let responseData = Object.values(info.timeline);
        let yesterdayData = responseData.length > 0 ? responseData[responseData.length - 15] : 0;
        let country = document.getElementById("country")

        date.innerHTML = ""
        country.innerHTML = ""

        country.append("" + info.country)
        date.append("" + yesterdayData)

        vaccinesChart.data.datasets[0].data = responseData;
        vaccinesChart.data.labels = Object.keys(info.timeline);
        vaccinesChart.update();

    });

    async function getHistory30(getVaccinationHistoryFor30days) {
        let response = await fetch(getVaccinationHistoryFor30days)
        let info = await response.json()
        return info;
    }
    getHistory30(getVaccinationHistoryFor30days).then(function(info) {
        let responseData = Object.values(info.timeline);
        let yesterdayData = responseData.length > 0 ? responseData[responseData.length - 30] : 0;
        let country = document.getElementById("country")

        date.innerHTML = ""
        country.innerHTML = ""

        country.append("" + info.country)
        date.append("" + yesterdayData)

        vaccinesChart.data.datasets[0].data = responseData;
        vaccinesChart.data.labels = Object.keys(info.timeline);
        vaccinesChart.update();
    });

    async function getHistoryAll(getVaccinationHistoryAll) {
        let response = await fetch(getVaccinationHistoryAll)
        let info = await response.json()
        return info;
    }
    getHistoryAll(getVaccinationHistoryAll).then(function(info) {
        let responseData = Object.values(info.timeline);
        let yesterdayData = responseData.length > 0 ? responseData[responseData.length - 1] : 0;
        let country = document.getElementById("country")

        date.innerHTML = ""
        country.innerHTML = ""

        country.append("" + info.country)
        date.append("" + yesterdayData)

        vaccinesChart.data.datasets[0].data = responseData;
        vaccinesChart.data.labels = Object.keys(info.timeline);
        vaccinesChart.update();

    })
}

const ctx = document.getElementById("vaccinesChart").getContext("2d");
const form = document.getElementById("SearchBox");
const bar = document.getElementById("bar");
const line = document.getElementById("line");
const bubble = document.getElementById("bubble");
form.addEventListener("submit", submitSearchBoxForm);
vaccinesChart = getchart([], [], []);


bar.addEventListener('click', changetobar);
line.addEventListener('click', changetoline);
bubble.addEventListener('click', changetobubble);

function getchart(data) {
    vaccinesChart = new Chart(ctx, {
        type: 'line',
        data: {
            datasets: [{
                label: 'Vaccines',
                data: data,
                fill: false,
                borderColor: 'black',
                backgroundColor: 'green',
                borderWidth: 3

            }, ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            indexAxis: 'y',
            scales: {
                y: {
                    beginAtZero: true
                },
                x: {
                    beginAtZero: true
                }
            },
        }
    });

    return vaccinesChart;
}
const monthsName = ["January", 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

function formatdate(dateString) {
    let date = new Date(dateString);
    return `${date.getDate()} ${monthsName[date.getMonth()-1]}`;
}

function createChartData(data) {
    return Object.entries(data).map(function(entry) {
        return { 'x': entry[0], 'y': entry[1] };

    })
}

function changetoline() {
    const typeupdate = 'line';
    vaccinesChart.config.type = typeupdate;
    vaccinesChart.update();
};

function changetobar() {
    const typeupdate = 'bar';
    vaccinesChart.config.type = typeupdate;
    vaccinesChart.update();
}

function changetobubble() {
    const typeupdate = 'bubble';
    vaccinesChart.config.type = typeupdate;
    vaccinesChart.update();
}