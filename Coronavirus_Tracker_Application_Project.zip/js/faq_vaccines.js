function accordion(id) {
    var x = document.getElementById(id);
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
        x.previousElementSibling.className =
            x.previousElementSibling.className.replace("w3-black", "w3-red");
    } else {
        x.className = x.className.replace(" w3-show", "");
        x.previousElementSibling.className =
            x.previousElementSibling.className.replace("w3-red", "w3-black");
    }
}

var divimage = document.getElementById('div-image');

var img = document.getElementById('imageNumber');
var divimageImg = document.getElementById("imageid");
var captionText = document.getElementById("imagecaption");
img.onclick = function() {
    divimage.style.display = "block";
    divimageImg.src = this.src;
    divimageImg.alt = this.alt;
}

divimage.onclick = function() {
    imageid.className += "out";
    setTimeout(function() {
        divimage.style.display = "none";
        imageid.className = "imageclass-content";
    }, 400);

}

var divimage33 = document.getElementById('div-image33');

var img = document.getElementById('imageNumber33');
var divimage33Img = document.getElementById("imageid33");
var captionText = document.getElementById("imagecaption33");
img.onclick = function() {
    divimage33.style.display = "block";
    divimage33Img.src = this.src;
    divimage33Img.alt = this.alt;
}

divimage33.onclick = function() {
    imageid33.className += "out";
    setTimeout(function() {
        divimage33.style.display = "none";
        imageid33.className = "imageclass-content33";
    }, 400);

}

var divimage36 = document.getElementById('div-image36');

var img = document.getElementById('imageNumber36');
var divimage36Img = document.getElementById("imageid36");
var captionText = document.getElementById("imagecaption36");
img.onclick = function() {
    divimage36.style.display = "block";
    divimage36Img.src = this.src;
    divimage36Img.alt = this.alt;
}

divimage36.onclick = function() {
    imageid36.className += "out";
    setTimeout(function() {
        divimage36.style.display = "none";
        imageid36.className = "imageclass-content36";
    }, 400);

}

var divimage37 = document.getElementById('div-image37');

var img = document.getElementById('imageNumber37');
var divimage37Img = document.getElementById("imageid37");
var captionText = document.getElementById("imagecaption37");
img.onclick = function() {
    divimage37.style.display = "block";
    divimage37Img.src = this.src;
    divimage37Img.alt = this.alt;
}

divimage37.onclick = function() {
    imageid37.className += "out";
    setTimeout(function() {
        divimage37.style.display = "none";
        imageid37.className = "imageclass-content37";
    }, 400);

}

var divimage39 = document.getElementById('div-image39');

var img = document.getElementById('imageNumber39');
var divimage39Img = document.getElementById("imageid39");
var captionText = document.getElementById("imagecaption39");
img.onclick = function() {
    divimage39.style.display = "block";
    divimage39Img.src = this.src;
    divimage39Img.alt = this.alt;
}

divimage39.onclick = function() {
    imageid39.className += "out";
    setTimeout(function() {
        divimage39.style.display = "none";
        imageid39.className = "imageclass-content39";
    }, 400);

}

var divimage42 = document.getElementById('div-image42');

var img = document.getElementById('imageNumber42');
var divimage42Img = document.getElementById("imageid42");
var captionText = document.getElementById("imagecaption42");
img.onclick = function() {
    divimage42.style.display = "block";
    divimage42Img.src = this.src;
    divimage42Img.alt = this.alt;
}

divimage42.onclick = function() {
    imageid42.className += "out";
    setTimeout(function() {
        divimage42.style.display = "none";
        imageid42.className = "imageclass-content42";
    }, 400);

}


var divimage44 = document.getElementById('div-image44');

var img = document.getElementById('imageNumber44');
var divimage44Img = document.getElementById("imageid44");
var captionText = document.getElementById("imagecaption44");
img.onclick = function() {
    divimage44.style.display = "block";
    divimage44Img.src = this.src;
    divimage44Img.alt = this.alt;
}

divimage44.onclick = function() {
    imageid33.className += "out";
    setTimeout(function() {
        divimage44.style.display = "none";
        imageid44.className = "imageclass-content33";
    }, 400);

}