function coronavirusInformation(id) {
    var x = document.getElementById(id);
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
        x.previousElementSibling.className =
            x.previousElementSibling.className.replace("w3-black", "w3-red");
    } else {
        x.className = x.className.replace(" w3-show", "");
        x.previousElementSibling.className =
            x.previousElementSibling.className.replace("w3-red", "w3-black");
    }
}

var divimage16 = document.getElementById('div-image16');


var img = document.getElementById('imageNumber16');
var divimage16Img = document.getElementById("imageid16");
var captionText = document.getElementById("imagecaption16");
img.onclick = function() {
    divimage16.style.display = "block";
    divimage16Img.src = this.src;
    divimage16Img.alt = this.alt;
}



divimage16.onclick = function() {
    imageid16.className += "out";
    setTimeout(function() {
        divimage16.style.display = "none";
        imageid16.className = "imageclass-content16";
    }, 400);

}