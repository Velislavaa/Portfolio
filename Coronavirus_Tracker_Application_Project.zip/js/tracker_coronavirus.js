let user_country_selected;
let covidChart;

function fetchData(user_country) {
    user_country_selected = user_country;
}

function submitSearchBoxForm(e) {
    e.preventDefault()

    var country = user_country_selected;
    var url = "https://corona.lmao.ninja/v2/countries/" + country
    let getCoronaHistoryInfoAll = "https://disease.sh/v3/covid-19/historical/" + country + "/?lastdays=all"
    Data(url)

    async function getHistoryAll(getCoronaHistoryInfoAll) {

        let response = await fetch(getCoronaHistoryInfoAll)
        let info = await response.json()
        return info;
    }

    getHistoryAll(getCoronaHistoryInfoAll).then(function(info) {
        let responseCases = Object.values(info.timeline.cases);
        let responseDeaths = Object.values(info.timeline.deaths);
        let responseRecovered = Object.values(info.timeline.recovered);
        let yesterdayCases = responseCases.length > 0 ? responseCases[responseCases.length - 1] : 0;
        let yesterdayDeaths = responseDeaths.length > 0 ? responseDeaths[responseCases.length - 1] : 0;
        let yesterdayRecovers = responseRecovered.length > 0 ? responseRecovered[responseRecovered.length - 1] : 0;

        cases.innerHTML = "";

        cases.append("" + yesterdayCases)
        date.append("" + yesterdayDeaths)

        covidChart.data.datasets[0].data = responseCases;
        covidChart.data.datasets[1].data = responseRecovered;
        covidChart.data.datasets[2].data = responseDeaths;
        covidChart.data.labels = Object.keys(info.timeline.cases);
        covidChart.update();
    });

    const ctx = document.getElementById("covidChart").getContext("2d");
    const form = document.getElementById("SearchBox");
    form.addEventListener("submit", submitSearchBoxForm);
    covidChart = getchart([], [], []);

    const bar = document.getElementById("bar");
    const line = document.getElementById("line");
    const bubble = document.getElementById("bubble");


    bar.addEventListener('click', changetobar);
    line.addEventListener('click', changetoline);
    bubble.addEventListener('click', changetobubble);

    async function Data(url) {
        let response = await fetch(url)

        let info = await response.json()
        let length = info.length
        let index = length - 1

        let flag = document.getElementById("flag").src = info.countryInfo.flag
        let population = document.getElementById("population")
        let country = document.getElementById("country")
        let cases = document.getElementById("cases")
        let recovered = document.getElementById("recovered")
        let deaths = document.getElementById("deaths")

        flag.innerHTML = `<img src="${info.countryInfo.flag}"/>`
        population.innerHTML = ""
        country.innerHTML = ""
        cases.innerHTML = ""
        recovered.innerHTML = ""
        deaths.innerHTML = ""

        population.append("" + info.population)
        country.append("" + info.country)
        cases.append("" + info.cases)
        recovered.append("" + info.recovered)
        deaths.append("" + info.deaths)
    }

    function getchart(cases, recovered, deaths) {
        covidChart = new Chart(ctx, {
            type: 'line',
            data: {
                datasets: [{
                        label: 'Total Cases',
                        data: cases,
                        fill: false,
                        borderColor: 'red',
                        backgroundColor: '#2196f3',
                        borderWidth: 3
                    },
                    {
                        label: 'Recovered',
                        data: recovered,
                        fill: false,
                        borderColor: 'green',
                        backgroundColor: '#2196f3',
                        borderWidth: 3

                    },
                    {
                        label: 'Deaths',
                        data: deaths,
                        fill: false,
                        borderColor: 'black',
                        backgroundColor: '#2196f3',
                        borderWidth: 3

                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: 'y',
                scales: {
                    y: {
                        beginAtZero: true
                    },
                    x: {
                        beginAtZero: true
                    }
                }
            }
        });
        return covidChart;
    }
    const monthsName = ["January", 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

    function formatdate(dateString) {
        let date = new Date(dateString);
        return `${date.getDate()} ${monthsName[date.getMonth()-1]}`;
    }

    function createChartData(data) {
        return Object.entries(data).map(function(entry) {
            return { 'x': entry[0], 'y': entry[1] };

        })
    }
}

function changetoline() {
    const typeupdate = 'line';
    covidChart.config.type = typeupdate;
    covidChart.update();
};

function changetobar() {
    const typeupdate = 'bar';
    covidChart.config.type = typeupdate;
    covidChart.update();
}

function changetobubble() {
    const typeupdate = 'bubble';
    covidChart.config.type = typeupdate;
    covidChart.update();
}