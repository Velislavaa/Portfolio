function openNavBar() {
    document.getElementById("bar").style.width = "250px";
    document.getElementById("main_content").style.marginLeft = "250px";
}

function closeNavBar() {
    document.getElementById("bar").style.width = "0";
    document.getElementById("main_content").style.marginLeft = "0";
}