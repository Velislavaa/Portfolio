var slidenumber = 1;
showfactsSlides(slidenumber);

function Slideabove(n) {
    showfactsSlides(slidenumber += n);
}

function Slidenumber(n) {
    showfactsSlides(slidenumber = n);
}

function showfactsSlides(n) {
    var i;
    var factsslides = document.getElementsByClassName("factsShow");
    var points = document.getElementsByClassName("point");
    if (n > factsslides.length) { slidenumber = 1 }
    if (n < 1) { slidenumber = factsslides.length }
    for (i = 0; i < factsslides.length; i++) {
        factsslides[i].style.display = "none";
    }
    for (i = 0; i < points.length; i++) {
        points[i].className = points[i].className.replace(" active", "");
    }
    factsslides[slidenumber - 1].style.display = "block";
    points[slidenumber - 1].className += " active";
}

function onClick(element) {
    document.getElementById("3.jpg").src = element.src;
    document.getElementById("3.jpg").style.display = "block";
    var captionText = document.getElementById("caption");
    captionText.innerHTML = element.alt;
}

var factsShow = document.getElementById("factsShow");

function w3_open() {
    if (factsShow.style.display === 'block') {
        factsShow.style.display = 'none';
    } else {
        factsShow.style.display = 'block';
    }
}

function w3_close() {
    factsShow.style.display = "none";
}